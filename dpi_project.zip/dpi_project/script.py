'''
@Author: TareqAhamed

'''
import os
import sys

def choose(dir_path, value):

	try:
		MAIN_DIR = fr'{dir_path}'
		count = 0

		dir_path = MAIN_DIR + fr'\{value}'
		for path in os.scandir(dir_path):
		    if path.is_file():
		        count += 1
		# print('file count:', count)
		if count >= 3:
			my_dict = {}
			var_names = []

			try:
				for i in range(count):
					var_name = f"list{i+1}" # creating variables
					var_names.append(var_name) # assining the variables as dictonary key
					my_dict[var_name] = [] # creating dictory list
					try:
						with open(rf"{value}/set-{i+1}.txt", "r", encoding="utf-8") as f:
							for line in f:
								my_dict[var_name].append(line.strip())
					except FileNotFoundError:
						print(f"{value} => File not found")
						sys.exit()
			except:
				pass



			final_list = []

			try:
				for i in range(len(var_names)):
					for j in my_dict[var_names[i]]: # accessing dictonary list
						if j in my_dict[var_names[i+1]] and j in my_dict[var_names[i+2]]: # checking if the question is atleast in 3 sets.
							if j not in final_list: # checking if the value is already in the list or not
								final_list.append(j)

			except IndexError:
				pass


			try:
				os.chdir(MAIN_DIR)
				folder_name = f"output\\final_{value}"
				os.makedirs(folder_name)
				save_file = f"{folder_name}\\final_{value}.txt"

				with open(save_file, "w", encoding="utf-8") as f:
					for data in final_list:
						f.write(data)
						f.write("\n")
				print(f"{value} => {final_list}")

			except FileExistsError:
				print("File already exists. Please delete the output folder.")
				sys.exit()


		else:
			print("At least 3 set needed")
			sys.exit()

	except Exception as e:
		print(e)
		sys.exit()
	


if __name__ == '__main__':
	# choose("O:\dpi_project", "extra_short")
	# choose("O:\dpi_project", "short")
	# choose("O:\dpi_project", "big")

	dir_path = os.getcwd()
	extra_short_path = sys.argv[1]
	short_path = sys.argv[2]
	big_path = sys.argv[3]

	choose(dir_path, extra_short_path)
	choose(dir_path, short_path)
	choose(dir_path, big_path)

