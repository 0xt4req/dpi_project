import os

MAIN_DIR = r'O:\dpi_project'
count = 0

'''

set_1_list = []
set_2_list = []

new_list = []

with open("set-1.txt",'r',encoding = 'utf-8') as f: 
    for line in f:
    	set_1_list.append(line.strip())

with open("set-2.txt",'r',encoding = 'utf-8') as f: 
    for line in f:
    	set_2_list.append(line.strip())


count = 1
for i in set_1_list:
	if i in set_2_list:
		new_list.append(i)
		with open("final-set.txt", "a", encoding="utf-8") as f:
			f.write(i)
			f.write("\n")

print(set_1_list)
print(set_2_list)
print(new_list)

'''
# import os


# import os

# MAIN_DIR = r'O:\dpi_project'
# count = 0
# dir_path = MAIN_DIR + r'\short'
# for path in os.scandir(dir_path):
#     if path.is_file():
#         count += 1
# print('file count:', count)

# lists = [[]] * count
# for i in range(0,count):
# 	with open(rf"short/set-{i+1}.txt", "r", encoding="utf-8") as f:
# 		for line in f:
# 			lists[i].append(line.strip())


# print(lists)

# new_list = []
# for i in range(count):
# 	for j in lists[i]:
# 		if j in lists[i]:
# 			new_list.append(j)


# print(new_list)
 
import os

MAIN_DIR = 'O:\\dpi_project'
os.chdir(MAIN_DIR)
value = "short"
folder_name = f"final_{value}"
os.makedirs(folder_name)
save_file = f"{folder_name}\\final_{value}.txt"
print(save_file)

with open(save_file, "w", encoding="utf-8") as f:
	f.write("This is short question")